Author: Zachary Reed
Description: Readme for Project 1
Date: 4/15/2020

To run proj1.cpp type the following in the command line on a linux machine:

$ runproj1

