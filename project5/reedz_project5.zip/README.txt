Author: Zachary Reed
Description: Readme for Project 5
Date: 5/20/2020

To run proj5.cu type the following in the command line on a flip machine:

$ ssh submit-c.hpc.engr.oregonstate.edu
$ module load slurm

cd to directory

$ sbatch runproj5.bash


