Author: Zachary Reed
Description: Readme for Project 2
Date: 4/26/2020

To run proj2.cpp type the following in the command line on a linux machine:

$ runproj2

