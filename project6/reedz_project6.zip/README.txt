Author: Zachary Reed
Description: Readme for Project 6
Date: 5/31/2020

To run proj6.cpp type the following in the command line on a flip machine:

$ ssh submit-c.hpc.engr.oregonstate.edu
$ module load slurm

cd to directory

$ sbatch runproj6.bash


