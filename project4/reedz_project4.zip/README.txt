Author: Zachary Reed
Description: Readme for Project 4
Date: 5/11/2020

To run proj4.cpp type the following in the command line on a linux machine:

$ runproj4

